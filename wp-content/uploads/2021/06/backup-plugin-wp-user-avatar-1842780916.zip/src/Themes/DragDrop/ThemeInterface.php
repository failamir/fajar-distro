<?php

namespace ProfilePress\Core\Themes\DragDrop;


interface ThemeInterface
{
    public function form_structure();

    public function form_css();
}