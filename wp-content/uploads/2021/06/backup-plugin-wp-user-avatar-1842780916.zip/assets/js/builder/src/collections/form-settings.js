import Backbone from 'backbone';
import FormSetting from '../model/form-setting';

export default Backbone.Collection.extend({
    model: FormSetting
});