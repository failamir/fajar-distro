<?php

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if ( ! function_exists( 'kicker_yikes_inc_easy_mailchimp_extender_theme_setup9' ) ) {
    add_action( 'after_setup_theme', 'kicker_yikes_inc_easy_mailchimp_extender_theme_setup9', 9 );
    function kicker_yikes_inc_easy_mailchimp_extender_theme_setup9() {

        

        if ( is_admin() ) {
            add_filter( 'kicker_filter_tgmpa_required_plugins', 'kicker_yikes_inc_easy_mailchimp_extender_tgmpa_required_plugins' );
        }
    }
}

// Filter to add in the required plugins list
if ( ! function_exists( 'kicker_yikes_inc_easy_mailchimp_extender_tgmpa_required_plugins' ) ) {
    
    function kicker_yikes_inc_easy_mailchimp_extender_tgmpa_required_plugins( $list = array() ) {
        if ( kicker_storage_isset( 'required_plugins', 'yikes-inc-easy-mailchimp-extender' ) && kicker_storage_get_array( 'required_plugins', 'yikes-inc-easy-mailchimp-extender', 'install' ) !== false ) {
            $list[] = array(
                'name'     => kicker_storage_get_array( 'required_plugins', 'yikes-inc-easy-mailchimp-extender', 'title' ),
                'slug'     => 'yikes-inc-easy-mailchimp-extender',
                'required' => false,
            );
        }
        return $list;
    }
}

// Check if plugin installed and activated
if ( ! function_exists( 'kicker_exists_yikes_inc_easy_mailchimp_extender' ) ) {
    function kicker_exists_yikes_inc_easy_mailchimp_extender() {
        return function_exists( 'yikes_inc_easy_mailchimp_extender' );
    }
}

// Set plugin's specific importer options
if ( !function_exists( 'kicker_exists_yikes_inc_easy_mailchimp_extender_importer_set_options' ) ) {
    if (is_admin()) add_filter( 'trx_addons_filter_importer_options',    'kicker_exists_yikes_inc_easy_mailchimp_extender_importer_set_options' );
    function kicker_exists_yikes_inc_easy_mailchimp_extender_importer_set_options($options=array()) {   
        if ( kicker_exists_yikes_inc_easy_mailchimp_extender() && in_array('yikes-inc-easy-mailchimp-extender', $options['required_plugins']) ) {
            $options['additional_options'][]    = 'yikes_easy_mailchimp_extender_forms';                   
        }
        return $options;
    }
}
