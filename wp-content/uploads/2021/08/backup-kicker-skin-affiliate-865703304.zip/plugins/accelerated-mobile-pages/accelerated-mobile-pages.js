( function() {
	"use strict";
	var elements = ['.cmt-button-wrapper', '.ampforwp-comment-wrapper', '.post-pagination-meta', '.ampforwp-meta-taxonomy']
	elements.forEach(function(item, i, elements) {
		var element = document.querySelector(item);
		if (typeof(element) != 'undefined' && element != null) {
			var html = element.innerHTML;
			html = (html.trim) ? html.trim() : html.replace(/^\s+/,'');
			if ( html == ''  ) {
				element.remove();
			}
		}
	});
})(); 
