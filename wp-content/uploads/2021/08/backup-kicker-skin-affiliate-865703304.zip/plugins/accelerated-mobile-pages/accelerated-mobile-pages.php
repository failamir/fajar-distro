<?php

// Theme init priorities:
// 9 - register other filters (for installer, etc.)
if ( ! function_exists( 'kicker_accelerated_mobile_pages_theme_setup9' ) ) {
    add_action( 'after_setup_theme', 'kicker_accelerated_mobile_pages_theme_setup9', 9 );
    function kicker_accelerated_mobile_pages_theme_setup9() {
        if ( is_admin() ) {
            add_filter( 'kicker_filter_tgmpa_required_plugins', 'kicker_accelerated_mobile_pages_tgmpa_required_plugins' );
        }
    }
}

// Filter to add in the required plugins list
if ( ! function_exists( 'kicker_accelerated_mobile_pages_tgmpa_required_plugins' ) ) {    
    function kicker_accelerated_mobile_pages_tgmpa_required_plugins( $list = array() ) {
        if ( kicker_storage_isset( 'required_plugins', 'accelerated-mobile-pages' ) && kicker_storage_get_array( 'required_plugins', 'accelerated-mobile-pages', 'install' ) !== false ) {
            $list[] = array(
                'name'     => kicker_storage_get_array( 'required_plugins', 'accelerated-mobile-pages', 'title' ),
                'slug'     => 'accelerated-mobile-pages',
                'required' => false,
            );
        }
        return $list;
    }
}

// Check if plugin installed and activated
if ( ! function_exists( 'kicker_exists_accelerated_mobile_pages' ) ) {
    function kicker_exists_accelerated_mobile_pages() {
        return function_exists( 'ampforwp_add_custom_rewrite_rules' );
    }
}

// Set plugin's specific importer options
if ( !function_exists( 'kicker_exists_accelerated_mobile_pages_importer_set_options' ) ) {
    if (is_admin()) add_filter( 'trx_addons_filter_importer_options',    'kicker_exists_accelerated_mobile_pages_importer_set_options' );
    function kicker_exists_accelerated_mobile_pages_importer_set_options($options=array()) {   
        if ( kicker_exists_accelerated_mobile_pages() && in_array('accelerated-mobile-pages', $options['required_plugins']) ) {
            $options['additional_options'][]    = 'redux_builder_amp';                   
        }
        return $options;
    }
}

// Detect if current page is amp
if ( ! function_exists( 'kicker_skin_is_amp' ) ) {
    function kicker_skin_is_amp() {
        return function_exists( 'ampforwp_is_amp_endpoint' ) && ampforwp_is_amp_endpoint() ? true : false;
    }
}

// AMP styles 
if ( ! function_exists( 'kicker_skin_ampforwp_add_custom_css' ) ) {
    add_action('amp_post_template_css','kicker_skin_ampforwp_add_custom_css', 11);
    function kicker_skin_ampforwp_add_custom_css() {
        $css = kicker_fgc( kicker_get_file_dir( kicker_skins_get_current_skin_dir() . 'plugins/accelerated-mobile-pages/accelerated-mobile-pages.css' ) );
        if ( '' != $css ) {
            echo trim($css);
        }
        if ( is_rtl() ) {
            $css = kicker_fgc( kicker_get_file_dir( kicker_skins_get_current_skin_dir() . 'plugins/accelerated-mobile-pages/accelerated-mobile-pages-rtl.css' ) );            
            if ( '' != $css ) {
                echo trim($css);
            }
        }
    }
}

// AMP script 
if ( ! function_exists( 'kicker_skin_ampforwp_add_custom_js' ) ) {
    add_action('amp_footer_link', 'kicker_skin_ampforwp_add_custom_js');
    function kicker_skin_ampforwp_add_custom_js() {
        $js = kicker_fgc( kicker_get_file_dir(  kicker_skins_get_current_skin_dir() . 'plugins/accelerated-mobile-pages/accelerated-mobile-pages.js' ) );     
        if ( '' != $js ) {
           echo '<script>' . trim($js) . '</script>';
        }
    }
}