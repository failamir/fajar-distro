<?php
/* Contact form 7 support functions
------------------------------------------------------------------------------- */

// Remove styles and scripts for the frontend
if ( !function_exists( 'kicker_skin_cf7_load_scripts_front' ) ) {
	add_action( "wp_enqueue_scripts", 'kicker_skin_cf7_load_scripts_front', 10000 );
	function kicker_skin_cf7_load_scripts_front( $force = false ) {
		if ( kicker_exists_trx_addons() && kicker_exists_cf7() && trx_addons_is_on( trx_addons_get_option( 'cf7_optimization' ) ) ) {			
			static $loaded = false;

			$entiries_cf7 = array(
								array( 'type' => 'sc',  'sc' => 'contact-form-7' ),
								array( 'type' => 'gb',  'sc' => 'wp:contact-form-7/' ),
								array( 'type' => 'elm', 'sc' => '"widgetType":"trx_sc_contact_form_7"' ),
							);

			if ( ! $loaded && ( $force === true
								|| $force === 'gutenberg'
								|| kicker_skin_is_preview()
								|| kicker_skin_sc_check_in_content( array(	// or if a shortcode is present in the current page
										'sc' => 'contact-form-7',
										'entries' => $entiries_cf7
									) )
								)
			) {
				$loaded = true;
			} else {	
				// Styles
				if ( wp_style_is('contact-form-7') ) {
		        	wp_dequeue_style( 'contact-form-7' );
				}
				if ( wp_style_is('trx_addons-cf7') ) {
		        	wp_dequeue_style( 'trx_addons-cf7' );
				}
				if ( wp_style_is('kicker-contact-form-7') ) {
		        	wp_dequeue_style( 'kicker-contact-form-7' );
				}

				// Scripts			
				if ( wp_script_is('contact-form-7') ) {
		        	wp_dequeue_script( 'contact-form-7' );
				}	
				if ( wp_script_is('trx_addons-cf7') ) {
		        	wp_dequeue_script( 'trx_addons-cf7' );
				}
				if ( wp_script_is('kicker-contact-form-7') ) {
		        	wp_dequeue_script( 'kicker-contact-form-7' );
				}
			}
		}
	}
}