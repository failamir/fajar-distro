/* global jQuery:false */
/* global KICKER_STORAGE:false */

( function() {
	"use strict";

	var $window   = jQuery( window ),
		$document = jQuery( document ),
		is_touch_device = ('ontouchstart' in document.documentElement);

	// Slider min width
	kicker_add_filter('trx_addons_filter_slider_controller_slide_width', function(width) {
		return 140;
	});

	// Slider all params
	kicker_add_filter('trx_addons_filter_slider_init_args', function(params, slider) {
		var spv = params['slidesPerView'];
		params['lazy'] = true;
		params['effect'] = slider.data('effect') ? slider.data('effect') : (spv == 1 && slider.parents('.sc_blogger[class*="sc_blogger_default_over"]').length > 0 ? 'fade' : 'slide');
		return params;
	});
	
	// Slider controls html
	kicker_add_filter('trx_addons_filter_slider_controls_html_fraction', function(html, controls) {
		html = html.replace('</span>/<span', '</span><span');
		return html;
	});
	
	// Blogger minimal height
	kicker_add_filter('trx_addons_filter_set_min_height_on_switch_tabs', function(set, sc) {
		if ( sc.parents('.sc_layouts_submenu').length !== 0 ) {
			set = false;
		}
		return set;
	});
	
	// Superfish menu params
	kicker_add_filter('trx_addons_filter_menu_init_args', function(sf_init) {
		sf_init['delay'] = is_touch_device ? 500 : 200;
		sf_init['speed'] = 0;
		sf_init['speedOut'] = 200;
		return sf_init;
	});
	
	// Superfish method - onBeforeShow
	kicker_add_action('trx_addons_action_menu_on_before_show', function(menu_item) {
		if ( !is_touch_device ) {
			menu_item.addClass('wait');
		}
	});
	
	// Superfish animation in
	kicker_add_filter('trx_addons_filter_menu_animation_in', function(animated, menu_item, animation_in, animation_out) {		
		var delay = 0;
		if ( !is_touch_device ) {
			delay = menu_item.parents('ul.sub-menu').length > 0 ? 200 : 500;
		}
		window.menuFadeTimer = setTimeout(function() {
			if ( menu_item.hasClass('animated') && menu_item.hasClass(animation_out) ) {
				menu_item.removeClass('animated fast '+animation_out);
			}
			menu_item.removeClass('wait').addClass('animated fast '+animation_in);
		}, delay);
		return true;
	});

	// Superfish before animation out
	kicker_add_action('trx_addons_action_menu_before_animation_out', function() {
		clearTimeout(window.menuFadeTimer);
	});

	// Timer for fix/unfix row
	kicker_add_filter('trx_addons_filter_sc_layouts_row_fixed_off_timeout', function(time) {		
		return 200;
	});	

	// Stretch sumbenu
	kicker_add_filter('trx_addons_filter_stretch_menu_to', function(result, menu_item) {
		// Change parent container for the fullwidth submenu
		if ( menu_item.parents('.elementor-section-full_width').length > 0 && menu_item.parents('.elementor-section-boxed').length == 0 ) {
			result = 'window';
		}				
		return result;
	});

	// Elementor menu
	if ( jQuery('.elementor-nav-menu').length > 0 ) { 
		jQuery('.elementor-nav-menu .sc_layouts_submenu').each(function() {
			jQuery(this).find('> li').remove();
			jQuery(this).addClass('sub-menu elementor-nav-menu--dropdown').removeClass('sc_layouts_submenu').append('<li class="menu-item"><span><a href="#" style="pointer-events: none;">' + KICKER_STORAGE['submenu_not_allowed'] + '</a></span></li>');
		});
	}

	// Init skin-specific actions on first run
	// Attention! Don't forget to add the class "inited" and check it to prevent re-initialize the elements	
	$document.on('action.ready_kicker', function() {
		// Add class to body if current deviced is touched
		if ( is_touch_device ) {
			jQuery('body').addClass('touch_device');
		}

		// Social buttons
		jQuery('.mo-openid-app-icons .btn i').removeAttr('style');
		jQuery('.mo-openid-app-icons .btn').removeAttr('style').removeClass('btn').addClass('sc_button');

		// Register/login tabs
		jQuery('.trx_addons_tabs_title_register a').on('click', function() {
			jQuery('#trx_addons_login_content').hide();
			jQuery('#trx_addons_register_content').show();
		});
		jQuery('.trx_addons_tabs_title_login a').on('click', function() {
			jQuery('#trx_addons_register_content').hide();
			jQuery('#trx_addons_login_content').show();
		});
		
		// Recent News
		jQuery('.sc_recent_news.sc_recent_news_style_news-magazine.magazine_type_on_plate').each(function(){
			jQuery(this).parent().addClass('on_plate');		
		});	

		// Close panel on click on the page
		jQuery('body').on('click', function(e) {
			if ( jQuery(e.target).closest('.sc_layouts_panel').length ) { 
			 	return;    
			} 
			if(jQuery('.sc_layouts_panel_opened').length > 0) {
				trx_addons_close_panel(jQuery('.sc_layouts_panel_opened'));
			}			
		});	

		// Infinite scroll in the single posts
		KICKER_STORAGE['cur_page_id'] = jQuery('body').hasClass('single-post') ? jQuery('body').attr('class').match(/postid-[0-9]+/g).toString().replace('postid-', '') : ''; 

		// Post navigation
		kicker_skin_nav_links_init();

		// Comments
		kicker_skin_comments_init(); 

		// Mailchimp
		kicker_skin_mailchimp_init();

		// Post blocks
		kicker_skin_post_blocks_init();

		// Blog posts init
		kicker_skin_blog_posts_init();

		//Hide elementor video controls
		kicker_skin_hide_elementor_video_controls();
	});

	// Init skin-specific actions after page load
	$window.load(function() {

		// Video List (add padding when horizontal scroll)
		jQuery('.trx_addons_video_list_controller_wrap').each(function() {
		    var $this = jQuery(this),
		        scrollWidth = this.scrollWidth,
		        width = Math.ceil($this.outerWidth());
		    if(scrollWidth > width)	{
		    	$this.css('paddingBottom', '15px');
		    }	    
		});	

		// Output only user name "Widget: Author (PowerKit)" 
		jQuery('.pk-widget-author .pk-author-title a').each(function() {
			var authorTitle = jQuery(this),
			    fullName = authorTitle.text(),
			    parsedName = fullName.split(' '),
			    authorTitleWrapper = authorTitle.parent();

		    authorTitle.html(parsedName[0]);
		    authorTitleWrapper.css('opacity','1');
		    setTimeout( function() {
            	authorTitleWrapper.siblings().css('opacity','1');
       		}, 500);
		});

		// Counter align extending from column align
		jQuery('.elementor-counter .elementor-counter-number-wrapper').each(function() {
		    var counter = jQuery(this),
		    	counterParentJC = counter.parents('.sc_layouts_column').css('justify-content'),
		    	counterParentTA = counter.parents('.sc_layouts_column').css('text-align');
		    counter.css('justify-content', counterParentJC).siblings('.elementor-counter-title').css('text-align', counterParentTA);
		});

		// Wrap recent post widget title for underline animation
		jQuery('.sc_recent_posts .post_content .post_title a').each(function() {
		   jQuery(this).wrapInner('<span></span>');
		});

		// Position of Animated Item (on page load)
		jQuery('.ta_mouse_wheel').each(function() {
			var item = jQuery(this);
			kicker_skin_mousewheelItemPosition(item);
		});

		// Progress bar
		var scroll_progress = jQuery('.scroll_progress_fixed');
		if ( scroll_progress.length > 0 ) {
			scroll_progress.appendTo(jQuery('.sc_layouts_row_fixed'));
		}

		// Add icons wrapper for widget title
		kicker_skin_widget_title_icons_wrapper();
		
		// Replace mark text for "Widget: Rating Posts" 
		kicker_skin_rating_type_default();
		kicker_skin_rating_type_modern();

		// Visible on load
		kicker_skin_isVisibleOnLoad(".single-post .sc_blogger.alignright .sc_blogger_item", "kicker_animation_fade_in_up");
		kicker_skin_isVisibleOnLoad(".single-post .sc_blogger.alignleft .sc_blogger_item", "kicker_animation_fade_in_up");
	    kicker_skin_isVisibleOnLoad(".single-post .content_wrap .sc_widget_video", "kicker_animation_fade_in_up");
	    kicker_skin_isVisibleOnLoad(".single-post .content_wrap .sc_widget_slider", "kicker_animation_fade_in_up");

		// Title Animation 
		kicker_skin_isVisibleOnLoad(".widgettitle_icons_wrapper", "kicker_animation_fade_in");

		// Footer Animation 
		kicker_skin_isVisibleOnLoad(".footer_wrap .wp-widget-nav_menu li", "kicker_animation_fade_in"); 	
		kicker_skin_isVisibleOnLoad(".footer_wrap .widget_nav_menu li", "kicker_animation_fade_in");
		kicker_skin_isVisibleOnLoad(".footer_wrap .mailchimp-form-2 .EMAIL-label", "kicker_animation_width");

		// Blogger images
		kicker_skin_blogger_image_init();

		// Audio
		kicker_skin_audio_init();

		// Blogger slider
		kicker_skin_blogger_slider_init();

		// Post header
		kicker_skin_post_header_init();
	}); 
	 
	// On Scroll Effect after page load
	$document.on('action.scroll_kicker', function() { 

		// Infinite scroll in the single posts
		kicker_skin_infinite_scroll_single_posts();

		// Progress bar
		var scroll_progress = jQuery('body > .scroll_progress_fixed');
		if ( scroll_progress.length > 0 ) {
			scroll_progress.appendTo(jQuery('.sc_layouts_row_fixed'));
		}

		// Blog Single Post Animation 
		kicker_skin_isVisible(".single-post .sc_blogger.alignright .sc_blogger_item", "kicker_animation_fade_in_up");
		kicker_skin_isVisible(".single-post .sc_blogger.alignleft .sc_blogger_item", "kicker_animation_fade_in_up");
	    kicker_skin_isVisible(".single-post .content_wrap .sc_widget_video", "kicker_animation_fade_in_up");
	    kicker_skin_isVisible(".single-post .content_wrap .sc_widget_slider", "kicker_animation_fade_in_up");

		// Title Animation 
		kicker_skin_isVisible(".widgettitle_icons_wrapper", "kicker_animation_fade_in");

		// Footer Animation 
		kicker_skin_isVisible(".footer_wrap .wp-widget-nav_menu li", "kicker_animation_fade_in"); 	
		kicker_skin_isVisible(".footer_wrap .widget_nav_menu li", "kicker_animation_fade_in");
		kicker_skin_isVisible(".footer_wrap .mailchimp-form-2 .EMAIL-label", "kicker_animation_width");

		// Mouse Wheel 
		kicker_skin_mousewheelScroll(".ta_mouse_wheel");

		// Parallax Images
		kicker_skin_imageParallax(".blogger_coverbg_parallax.sc_blogger_item_with_image .featured_bg_wrapper .featured_bg");
		kicker_skin_imageParallax(".blogger_coverbg_parallax .sc_blogger_item_with_image .featured_bg_wrapper .featured_bg");
		kicker_skin_imageParallax(".blogger_coverbg_parallax.post_format_image .featured_bg_wrapper .featured_bg");
		kicker_skin_imageParallax(".blogger_coverbg_parallax .post_format_image .featured_bg_wrapper .featured_bg");
	});

	// Skin-specific resize actions
	$document.on('action.resize_kicker', function() {
		// Video list
		jQuery('.trx_addons_video_list .trx_addons_video_player.video_play ').each(function(){	       			
   			jQuery(this).children('img').animate({
   				opacity: 0,
   				height: 0
   			}, 300).css('display', 'none').siblings('.video_embed').css('position', 'static');	       			
       	});
		jQuery('.trx_addons_video_list.trx_addons_video_list_type_news .trx_addons_video_player.video_play ').each(function(){
       		jQuery(this).parents('.trx_addons_video_list').find('.trx_addons_video_list_controller_item_active').addClass('hide_oveflow_image').siblings().removeClass('hide_oveflow_image');			
       	}); 
       	jQuery('.trx_addons_video_list.trx_addons_video_list_type_news .trx_addons_video_list_controller_item_link ').click(function(){
       		jQuery(this).parents('.trx_addons_video_list').find('.trx_addons_video_list_controller_item.hide_oveflow_image').removeClass('hide_oveflow_image');			
       	}); 	

		// Post blocks
		kicker_skin_post_blocks_init();

		// Blogger slider
		kicker_skin_blogger_slider_init();

		// Blog posts init
		kicker_skin_blog_posts_init();

		// Post header
		kicker_skin_post_header_init();
	});

	// Init changes in Elementor 
	$window.on( 'elementor/frontend/init', function() {
		if ( typeof window.elementorFrontend !== 'undefined' && typeof window.elementorFrontend.hooks !== 'undefined' ) {

			// If Elementor is in the Editor's Preview mode
			if ( elementorFrontend.isEditMode() ) {

				// Init elements after creation
				elementorFrontend.hooks.addAction( 'frontend/element_ready/global', function( $cont ) {
					kicker_skin_widget_title_icons_wrapper();
					kicker_skin_rating_type_modern();
					kicker_skin_rating_type_default();
					kicker_skin_blogger_image_init();					
					kicker_skin_hide_elementor_video_controls();
				} );
			}
		}
	});

	// Previous posts loading
	$document.on('action.got_ajax_response', function(event, params) {
		if (params['action'] == 'prev_post_loading') {

			var res_post_id = '';
			if ( params['result'] ) {
				var res =  jQuery( params['result'] );
				res_post_id = res.find('.content > article').attr('id');
				res_post_id = res_post_id.replace('post-', '');
			}

			jQuery.post(KICKER_STORAGE['ajax_url'], {
				action: 'kicker_skin_prev_post_loading',
				nonce: KICKER_STORAGE['ajax_nonce'],
				post_id: res_post_id
			}, function(response) {
				if (response) {
					// Append kadence styles to head
					jQuery('head').append(response);

					// Audio
					kicker_skin_audio_init();

					// Blogger images
					kicker_skin_blogger_image_init();

					// Post navigation
					kicker_skin_nav_links_init();

					// Post comments
					kicker_skin_comments_init();

					// Mailchimp
					kicker_skin_mailchimp_init();

					// Post blocks
					kicker_skin_post_blocks_init();

					// Post header
					kicker_skin_post_header_init();

					// Recalculate blocks parameters
					$document.trigger('resize');
				}
			});
		}
	});
	
	// LazyLoad trigger
	$document.on('action.after_lazy_load', function() {
		kicker_skin_blogger_image_init();
	});

	// Magnific Popup open trigger
	jQuery('.video_hover.trx_addons_popup_link').on('mfpOpen', function() {
		var x = jQuery('html').attr('style');
		if ( x ) {
			x = x.replace('overflow: hidden', 'overflow: hidden !important');
		}
		jQuery('html').attr('style', x);
	});

	// Infinite scroll in the single posts
	function kicker_skin_infinite_scroll_single_posts() {
		var single_post_scrollers  = jQuery( '.nav-links-single-scroll' );
		if ( single_post_scrollers.length === 0 ) {
			return;
		}

		var cur_page_id = KICKER_STORAGE['cur_page_id'],
			cur_page_link  = KICKER_STORAGE['cur_page_url'];

		single_post_scrollers.each( function() {
			var inf  = jQuery(this),
				link = inf.data('post-link'),
				off  = inf.offset().top,
				st   = $window.scrollTop(),
				wh   = $window.height();
			
			// Change location url
			if (inf.hasClass('nav-links-single-scroll-loaded')) {
				if (link && off < st + wh / 2) {
					cur_page_id = inf.data('post-prev-id');
				}				
			} 				
		} );

		// Infinite scroll in the single posts - Update post meta and share
		if (cur_page_link != location.href) {
			jQuery( '.sc_layouts_meta .post_meta_item' ).each(function() {
				var meta = jQuery(this);
				var meta_class = meta.attr('class'); 
				var meta_type = meta_class.split(' ');
				if ( meta_type.length > 1 ) {
					if ( meta_type[1] == 'post_share' ) {					
						var socials = jQuery( 'article#post-' + cur_page_id + ' .post_share .social_items:first');
						if ( socials.length > 0 ) {
							meta.find('.social_item').each(function() {
								var x =  socials.find('.social_item[data-count="' + jQuery(this).data('count') + '"]').attr('href');
								jQuery(this).attr('href', x).data('link', x);
							})
						}
					} else {
						var meta_clone = jQuery( 'article#post-' + cur_page_id + ' .post_header_wrap .' + meta_type[1] ).clone();
						if ( meta_clone.length > 0 ) {
							meta.replaceWith(meta_clone);
						}								
					}
				} 
			});
		}
	}

	// Audio
	function kicker_skin_audio_init() {
		jQuery('.post_header_wrap_in_header .post_featured.with_audio.with_thumb:not(.audio_inited)').each(function() {
			var featured = jQuery(this);
			if ( featured.find('.mejs-container').length > 0 ) {
				featured.addClass('audio_inited');
				var audio_wrap = featured.find('.post_audio');
				var audio = audio_wrap.find('audio')[0];
				var btn = jQuery('<div class="post_audio_btn"></div>');
				var header = featured.find(' + .post_header');
				if ( header.length == 0 ) {
					header = featured;
				}
				header.prepend(btn);
				audio_wrap.hide();
				btn.on('click', function() {
					audio_wrap.slideToggle(function(){
						audio_wrap.find('.mejs-playpause-button').click();
			        });
				});				
			} else {
				setTimeout(function(){
					kicker_skin_audio_init();
				}, 1000);
			}
		});
	}

	// Blog posts init
	function kicker_skin_blog_posts_init() {
		// Blog - Portfolio
		if( jQuery('.portfolio-masonry_wrap').length > 0 ) {
			jQuery('.portfolio-masonry_wrap .post_layout_portfolio').removeClass('inverse');
			jQuery('.portfolio-masonry_wrap').masonry();  
		} 

		// Relayout
		setTimeout( function() {
			jQuery('.portfolio-masonry_wrap .post_layout_portfolio').each(function() {
				var item = jQuery(this);
				var item_h = item.height();
				var info_h = item.find('.post_info').outerHeight();
				var formats = item.hasClass('post_format_audio') || item.hasClass('post_format_gallery') || item.hasClass('post_format_video');
				if ( formats ) {
					info_h = info_h + 72;
				}
				if ( info_h >= item_h ) {
					item.addClass('inverse');
				}
			});

			// Relayout
			if( jQuery('.portfolio-masonry_wrap').length > 0 ) {
				setTimeout( function() {
		  	 		jQuery('.portfolio-masonry_wrap').masonry();   
		  	 	}, 310 );
			}

  	  	}, 310 );

  	  	// Blog - Band
		jQuery('.post_layout_band .slider_container ').each(function() {
			if ( $window.width() <= 600 ) {
				jQuery(this).data('ratio', '16:9');
			} else {
				jQuery(this).data('ratio', '1:1');
			}
		});  	  	
	}
	
	// Blogger images
	function kicker_skin_blogger_image_init() {
		// Blogger Default - Classic Grid
		jQuery('.sc_blogger_item_default_classic.sc_blogger_item_image_position_top:not(.sc_blogger_item_info_over_image) .post_featured:not(.size_inited)').addClass('size_inited').each(function() {
			var image_width = jQuery(this).width();
			if (image_width > 430) {
				jQuery(this).parents('.sc_blogger_item').addClass('large_image');
			}
		});

		// Blogger Wide
		jQuery('.sc_blogger_item_wide:not(.sc_blogger_item_info_over_image) .post_featured:not(.size_inited)').addClass('size_inited').each(function() {
			var image_width = jQuery(this).width();
			if (image_width < 600) {
				jQuery(this).parents('.sc_blogger_item').addClass('small_image');
			}
		});

		// Blogger List
		jQuery('.sc_blogger_item_list:not(.sc_blogger_item_image_position_top) .post_featured:not(.size_inited)').addClass('size_inited').each(function() {
			var image_width = jQuery(this).width();
			if (image_width > 90 && image_width <= 100) {
				jQuery(this).parents('.sc_blogger_item').addClass('small_image');
			}
			if (image_width <= 90) {
				jQuery(this).parents('.sc_blogger_item').addClass('tiny_image');
			}
		});

		// Blogger Info over image - Modern
		jQuery('.sc_blogger_default_over_bottom_modern').each(function() { 
			var blogger = jQuery(this);						
			if ( blogger.find('.bg_mask_wrap').length == 0 ) {
				blogger.find('.sc_blogger_content, .trx_addons_columns_wrap, .masonry_wrap, .sc_blogger_slider > .slider_multi:not(.swiper-container-fade)').prepend('<div class="bg_mask_wrap"></div>');
			}

			// Create masks from post's images
			blogger.find('.sc_blogger_item:not(.bg_inited)').each(function() {
				var item = jQuery(this);
				var id = item.data('post-id');
				var img = item.find('.post_featured_wrap > img,	.post_featured > img');
				var img_url = '';

				// Check normal <img>
				if ( img.length > 0 ) {
					if ( jQuery('body').hasClass('allow_lazy_load') && !img.hasClass('lazyload_inited') ) {
						return;
					}
					img_url = img.attr('src');
				} else {
					// Check background images
					img = item.find('.featured_bg_wrapper .featured_bg');
					if ( img.length > 0 ) {
						if ( jQuery('body').hasClass('allow_lazy_load') && !img.hasClass('lazyload_inited') ) {
							return;
						}
						img_url = img.css('background-image').replace('url("', '').replace('")', '').replace("'", '').replace("'", '');
					} else {
						// Check sliders
						img = item.find('.slider-slide');
						if ( img.length > 0 ) {
							if ( jQuery('body').hasClass('allow_lazy_load') && !img.hasClass('lazyload_inited') ) {
								return;
							}
							img_url = img.css('background-image').replace('url("', '').replace('")', '').replace("'", '').replace("'", '');
						}
					}
				}

				if ( img_url != '' && id ) {
					if ( blogger.find('.sc_blogger_slider > .slider_multi:not(.swiper-container-fade)').length > 0 ) {
						blogger.addClass('with_slider').find('.sc_blogger_slider > .slider_multi:not(.swiper-container-fade) .bg_mask_wrap').prepend('<div class="bg_mask" data-post-id="'+id+'" style="background-image: url('+img_url+')"></div>');
					} else {
						blogger.find('.sc_blogger_content .bg_mask_wrap, .trx_addons_columns_wrap .bg_mask_wrap, .masonry_wrap .bg_mask_wrap').prepend('<div class="bg_mask" data-post-id="'+id+'" style="background-image: url('+img_url+')"></div>');
					}
				}

				item.addClass('bg_inited');
			});

			// Make first mask active
			if ( blogger.find('.sc_blogger_item.bg_inited').length > 0 && blogger.find('.bg_mask.active').length == 0) {
				blogger.find('.bg_mask:first-child').addClass('active');
			}

			// Change active mask after post hover
			blogger.find('.sc_blogger_item.bg_inited').on('mouseover', function() {
				var item = jQuery(this);  
				var id = item.data('post-id');
				var mask = blogger.find('.bg_mask[data-post-id="'+id+'"]');
				if ( id && mask.length > 0 && !mask.hasClass('active') ) {
					blogger.find('.bg_mask.active').removeClass('active')
					mask.addClass('active');
				}
			});
		});
	}

	// Post navigation
	function kicker_skin_nav_links_init() {
		// Duplicate post navigation
		jQuery('.nav-links-single.nav-links-fixed:not(.inited)').addClass('inited').each(function() {
			var links = jQuery(this);
			var clone = links.clone().removeClass('nav-links-fixed nav-links-with-thumbs');
			clone.insertAfter(links);
			links.find('.nav-arrow-label').each(function() {
				var i = jQuery(this);
				i.insertBefore(i.parent());
			});
		});
	}

	// Post comments
	function kicker_skin_comments_init() {
		// Add lines to parents
		jQuery('.comments_wrap:not(.inited)').addClass('inited').each(function() {
			var wrap = jQuery(this);
			var button = wrap.find('.form-submit input[type="submit"]').removeAttr('type').removeAttr('name');
			var val = button.val();
			button.replaceWith(jQuery('<button class="sc_button sc_button_default sc_button_size_large sc_button_with_icon sc_button_icon_right hover_style_icon_1 color_style_1"><span class="sc_button_icon"><span class="icon-comment-1"></span></span><span class="sc_button_text"><span class="sc_button_title">' + val + '</span></span></button>'));
			wrap.find('.comments_list_wrap ul > li > ul').each(function() {
				jQuery(this).parent().addClass('has-children');
			});
		});

		// Show/Hide Comments
		jQuery('.show_comments_button:not(.inited)').addClass('inited').on('click', function(e) {
			var bt = jQuery(this);
			if (bt.attr('href') == '#') {
				var comments_wrap = bt.parent().find('+ .comments_wrap');
				bt.toggleClass('opened').text(bt.data(bt.hasClass('opened') ? 'hide' : 'show'));
				comments_wrap.slideToggle(function() {
					comments_wrap.toggleClass('opened');
				});
				e.preventDefault();
				return false;
			}
		});
	}

	// Mailchimp
	function kicker_skin_mailchimp_init() {
		jQuery('.yikes-easy-mc-form:not(.inited)').addClass('inited').each(function() {
			var form = jQuery(this);
			var checkbox = form.find('.yikes-mailchimp-eu-compliance-label');
			var button = form.find('.yikes-easy-mc-submit-button');
			form.find('.yikes-easy-mc-submit-button').after(checkbox);
			// Add classes to Subscribe button
			if (form.hasClass('mailchimp-form-1')) {
				button.addClass('sc_button sc_button_with_icon sc_button_icon_right hover_style_icon_1 color_style_1');
			} else if (form.hasClass('mailchimp-form-6')) {
				button.addClass('sc_button sc_button_with_icon sc_button_icon_left hover_style_1 color_style_1');
			} else {
				button.addClass('sc_button sc_button_simple sc_button_with_icon sc_button_icon_left color_style_1');
			}
			button.find('.yikes-mailchimp-submit-button-span-text').addClass('sc_button_text');
			button.prepend('<span class="sc_button_icon"><span class="icon-plain"></span></span>');
		});
	}

	// Post header
	function kicker_skin_post_header_init() {
		var header = jQuery('.post_header_wrap_style_style-1.with_featured_image, .post_header_wrap_style_style-2.with_featured_image, .post_header_wrap_style_style-3.with_featured_image');
		header.find('.post_featured').css('min-height', 0); 

		if ( jQuery(header).find('.post_featured.with_gallery').length > 0 ) {
			return;
		}

		header.each(function() {
			var self = jQuery(this);
			var image_h = self.find('.post_featured').outerHeight();
			var info_h = self.find('.post_header').outerHeight();			
			var x = 140;
			if ( jQuery('body').hasClass('mobile_layout') ) {
				x = 80;
			}
			
			info_h = info_h + x; 
			if ( info_h >= image_h ) {
				self.find('.post_featured').css('min-height', info_h);
			}
		});
	}	

	// Post blocks
	function kicker_skin_post_blocks_init() {
		if ( jQuery('[class*="is-style-align"][class*="is-style-size"]').length > 0 ) {
			if ( $window.width() < 1680 ) {
				jQuery('[class*="is-style-align"][class*="is-style-size"] + .trx_addons_reviews_block').each(function(){
					jQuery(this).prev().addClass('responsive_view');
				});
			} else {
				jQuery('[class*="is-style-align"][class*="is-style-size"] + .trx_addons_reviews_block').each(function(){
					jQuery(this).prev().removeClass('responsive_view');
				});
			}
		}

		/* Banners */
		var banners = jQuery('.sidebar_hide .between_posts_banner_wrap');
		if ( banners.length > 0 ) {
			banners.css('width', jQuery('.page_content_wrap').width());
		}
	}

	// Add icons wrapper for widget title
	function kicker_skin_widget_title_icons_wrapper() {
		jQuery('.content .widget:not(.wp-widget-powerkit_widget_author) .widget_title:not(.inited), \
			.content .widget:not(.wp-widget-powerkit_widget_author) .widgettitle:not(.inited), \
			.sidebar .widget .widget_title:not(.inited), \
			.sidebar .widget .widgettitle:not(.inited), \
			.elementor-sidebar .widget .widget_title:not(.inited):not(.inited), \
			.elementor-sidebar .widget .widgettitle:not(.inited), \
			.elementor-sidebar .sc_item_title:not(.inited), \
			.footer_wrap .widget_recent_posts .sc_recent_posts_title_type_classic .widget_title:not(.inited), \
			.footer_wrap .widget_recent_posts .sc_recent_posts_title_type_classic .widgettitle:not(.inited), \
			.footer_wrap .widget_categories_list .widget_title:not(.inited), \
			.footer_wrap .widget_categories_list .widgettitle:not(.inited), \
			.footer_wrap .sc_widget_aboutme .widget_title:not(.inited), \
			.footer_wrap .sc_widget_aboutme .widgettitle:not(.inited), \
			.footer_wrap .wp-widget-search .widget_title:not(.inited), \
			.footer_wrap .wp-widget-search .widgettitle:not(.inited) ').each(function(){
			var self = jQuery(this).addClass('inited');
			var title = self.html();
			var titleWithIcons = title + "<span class="+'"widgettitle_icons_wrapper"'+"><span></span><span></span><span></span></span>";
			self.html(titleWithIcons);
		});
	}

	// Replace mark text for "Widget: Rating Posts" (type Default)
	function kicker_skin_rating_type_default() {
		jQuery('.sc_rating_posts.type_default .post_item:not(.inited)').each(function() {
			var self = jQuery(this).addClass('inited');
			var trxAddonsReviewsTextMax = self.find('.trx_addons_reviews_text_max'),	
			trxAddonsReviewsTextMark = self.find('.trx_addons_reviews_text_mark'),
			trxAddonsReviewsTextMaxText = trxAddonsReviewsTextMax.text(),
			trxAddonsReviewsTextMarkText = trxAddonsReviewsTextMark.text();

			if( trxAddonsReviewsTextMaxText == 5 || trxAddonsReviewsTextMaxText == 10 ) {
				var updatedMax = 100;
				var updatedMark = Math.round(trxAddonsReviewsTextMarkText * 100 / trxAddonsReviewsTextMaxText);
				trxAddonsReviewsTextMax.html(updatedMax);
				trxAddonsReviewsTextMark.html(updatedMark);
			}
		});		
	}

	// Replace mark text for "Widget: Rating Posts"  (type Modern)
	function kicker_skin_rating_type_modern() {
		jQuery('.sc_rating_posts.type_modern .post_item:not(.inited)').each(function(){
			var self = jQuery(this).addClass('inited');
			var trxAddonsReviewsTextMax = self.find('.trx_addons_reviews_text_max'),	
			trxAddonsReviewsTextMark = self.find('.trx_addons_reviews_text_mark'),
			trxAddonsReviewsTextMaxText = trxAddonsReviewsTextMax.text(),
			trxAddonsReviewsTextMarkText = trxAddonsReviewsTextMark.text();

			if( trxAddonsReviewsTextMaxText == 10 || trxAddonsReviewsTextMaxText == 100 ) {
				var updatedMax = 5;
				var updatedMark = trxAddonsReviewsTextMarkText / (trxAddonsReviewsTextMaxText / 5);
				updatedMark = updatedMark.toFixed(1);
				if(Number.isInteger(updatedMark)) {
					updatedMark += '.0';
				}
				trxAddonsReviewsTextMax.html(updatedMax);
				trxAddonsReviewsTextMark.html(updatedMark);
			}
		});	
	}
		
	// Blogger slider
	function kicker_skin_blogger_slider_init() {
		if ( jQuery('.sc_blogger_slider').length > 0 ) {
			// Cropp text if blogger style is Simple
			jQuery('.sc_blogger_slider .sc_blogger_item_list.sc_blogger_item_list_simple h6.sc_blogger_item_title').each(function(){
				var title = jQuery(this);
				title.removeClass('cropped');
				if ( title.find('span').width() > title.width() ) {
					title.addClass('cropped');
				} 
			})
		}
	}	

	// Animated item size
	function kicker_skin_itemVarsFunction(item) {
		var itemVars = {
			height: item.outerHeight(),
			topPosition: item.offset().top,
			bottomPosition: item.offset().top + item.outerHeight()
		};
		return itemVars;
	}

	// Browser window size
	function kicker_skin_windowVarsFunction() {
		var webWindow = $window;
		var windowVars = {
			height: webWindow.height(),
			topPosition: webWindow.scrollTop(),
			bottomPosition: webWindow.height() + webWindow.scrollTop()
		};
		return windowVars;
	}

	// Mouse weel animated element trigger
	function kicker_skin_mousewheelScroll(item) {
		var animationElements = jQuery.find(item),
			webWindow = kicker_skin_windowVarsFunction();

		jQuery.each(animationElements, function() {
			var element = jQuery(this),
				item = kicker_skin_itemVarsFunction(jQuery(this));
			if( element.hasClass('under_position') && (item.bottomPosition < webWindow.topPosition) ) {
				element.removeClass('under_position');
				element.addClass('over_position');
			} else if ( element.hasClass('over_position') && (item.topPosition > webWindow.bottomPosition) ) {
				element.removeClass('over_position');
				element.addClass('under_position');
			}

			// Click trigger
			element.click(function() {
				if ( element.hasClass('under_position') && (item.bottomPosition >= webWindow.topPosition) && (item.topPosition <= webWindow.bottomPosition)) {					
					jQuery('html,body').stop().animate({
			        	scrollTop: kicker_skin_scrollPosition(element, 'bottom') },
			        500, 'swing', function() {
			        	element.removeClass('under_position');
			        	setTimeout(function() {
					    	element.addClass('over_position');
					    }, 500);		
					});
				}
								 
				if ( element.hasClass('over_position') && (item.topPosition >= webWindow.topPosition) && (item.bottomPosition <= webWindow.bottomPosition)) {					
					jQuery('html,body').stop().animate({
			        	scrollTop: kicker_skin_scrollPosition(element, 'top') },
			        500, 'swing', function() {						    	
					    element.removeClass('over_position');
					    setTimeout(function() {
					    	element.addClass('under_position');	
					    }, 500);						    	
				  	});					
				} 
			});	
		});
	}

	// Position of animated item (on page load)
	function kicker_skin_mousewheelItemPosition(item) {
		var itemVars = kicker_skin_itemVarsFunction(item),
			windowVars = kicker_skin_windowVarsFunction(),
			position = '';
		if ((itemVars.topPosition < windowVars.topPosition) && ( itemVars.bottomPosition < windowVars.topPosition)) {
			position = 'over_position';
		} else if ((itemVars.topPosition > windowVars.bottomPosition) && ( itemVars.bottomPosition > windowVars.bottomPosition)) {
			position = 'under_position';
		}
		item.addClass(position);
	}

	// Position of animated item (on page load)
	function kicker_skin_isVisibleOnLoad(item, className, type = '') {
		var animatedItem = jQuery.find(item);
		jQuery.each(animatedItem, function() {
			if ( jQuery(this).is(':hidden') ) return;	
			var element = jQuery(this),
				itemVars = kicker_skin_itemVarsFunction(element),
				windowVars = kicker_skin_windowVarsFunction();			 
			if ((itemVars.topPosition >= windowVars.topPosition) && (itemVars.bottomPosition <= windowVars.bottomPosition)) {	
				element.addClass(className);
			} 
		})
	}

	// Make sure the picture is visible
	function kicker_skin_isVisible(item, className, type = '') {
		var animationElements = jQuery.find(item),
			webWindow = kicker_skin_windowVarsFunction();
		jQuery.each(animationElements, function() {		
			if ( jQuery(this).is(':hidden') ) return;		
			var element = jQuery(this),
				item = kicker_skin_itemVarsFunction(element);	
			if ( item.topPosition != 0 && item.bottomPosition != 0 && (item.bottomPosition >= webWindow.topPosition) && (item.topPosition <= webWindow.bottomPosition)) {
				element.addClass(className);
			} 
		});
	}

	// Function for image parallax by page scroll
	function kicker_skin_imageParallax(item) {
	    var windowTopPos = $window.scrollTop();
	   	if(windowTopPos > 1) {		    	
	    	jQuery(item).each(function(){
	    		var itemParallax = jQuery(this);
	    		var itemParallaxOff = itemParallax.hasClass('background_parallax_off');
	    		var itemTopPos = itemParallax.offset().top;
	    		var itembottomPosition = itemParallax.offset().top + itemParallax.outerHeight();
	    		var itemNewPos = parseInt((windowTopPos - itemTopPos)/12);
	    		var itemOpacity = parseInt(100 - itemNewPos);

	    		itemParallax.addClass('background_parallax');

	    		if(windowTopPos >= itembottomPosition) {
	    			itemParallax.addClass('background_parallax_off');
	    		} else if(windowTopPos <= itemTopPos){
	    			itemParallax.removeClass('background_parallax_off');
	    		}
		    	if(windowTopPos >= itemTopPos && !itemParallaxOff) {
		    		if(itemNewPos <= 50 && itemNewPos > 0) {
		    			jQuery(this).css({
		    				'background-position':'center ' + itemNewPos +'px',
		    				'opacity': '0.'+ itemOpacity
		    			}); 
		    		}					
		    	} else {
			    	jQuery(item).each(function(){
			    		jQuery(this).css({
		    				'background-position':'center 0',
		    				'opacity': '1'
		    			}); 
			    	});
			    }
	    	});
	    } else {
	    	jQuery(item).each(function(){
	    		jQuery(this).css({
    				'background-position':'center 0',
    				'opacity': '1'
    			});  
	    	});
		}
	}

	// Scroll To	
	function kicker_skin_scrollPosition(item, itemSibling) {
		var sibl,
			scroll,
			parentTop,
			siblTop,
			fixedRowsHeight,
			htmltagAttrStyleArr,
			htmltagAttrStyle = jQuery('html').attr('style'),
			parent = item.parents('section.elementor-element:not(.elementor-inner-section)'),
			siblName = 'section.elementor-element';
		
		if (htmltagAttrStyle.length > 0) {
			htmltagAttrStyleArr = htmltagAttrStyle.split(';')
			for (var i = 0; i < htmltagAttrStyleArr.length; i++) {
			  	if (htmltagAttrStyleArr[i].includes('--fixed-rows-height:')) {
			  		fixedRowsHeight = htmltagAttrStyleArr[i].replace('--fixed-rows-height:','').replace('px','');
			  	}
			}
		}

		if(itemSibling == 'top' ) {
			parentTop = parent.offset().top.toString();
			scroll = parentTop - fixedRowsHeight;	
			return scroll;
		} else if (itemSibling == 'bottom') {
			sibl = parent.next(siblName);
			if(sibl.attr('class') === undefined){
				return webWindow.bottomPosition;
			} else {
				var siblTop = sibl.offset().top.toString();
				scroll = siblTop - fixedRowsHeight;
				return scroll;
			}	
		}					
	}

	//Hide elementor video controls
	function kicker_skin_hide_elementor_video_controls() {
		var elemenor_video = jQuery('.elementor-video[controls]');
		if(elemenor_video.length == 0){
			jQuery('.elementor-video').attr('nocontrols', '');
		};
	}
})(); 
